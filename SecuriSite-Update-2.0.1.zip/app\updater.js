'use strict';

const { app, dialog, BrowserWindow } = require('electron');
const https = require('https');
const fs = require('fs');
const path = require('path');
const os = require('os');
const { URL } = require('url');

const VERSION_URL =
  'https://raw.githubusercontent.com/tbinici25-Bjk/SecuriSite-Updates/main/version.json';

function isNewer(remote, current) {
  const r = remote.split('.').map(Number);
  const c = current.split('.').map(Number);
  for (let i = 0; i < 3; i++) {
    if ((r[i] || 0) > (c[i] || 0)) return true;
    if ((r[i] || 0) < (c[i] || 0)) return false;
  }
  return false;
}

function fetchJSON(url) {
  return new Promise((resolve, reject) => {
    const u = new URL(url);
    https.get(
      { hostname: u.hostname, path: u.pathname + u.search,
        headers: { 'User-Agent': 'SecuriSite-Updater/1.0' } },
      (res) => {
        if (res.statusCode === 301 || res.statusCode === 302) {
          return fetchJSON(res.headers.location).then(resolve).catch(reject);
        }
        let data = '';
        res.on('data', chunk => (data += chunk));
        res.on('end', () => {
          try { resolve(JSON.parse(data)); }
          catch (e) { reject(new Error('JSON parse hatasi: ' + e.message)); }
        });
        res.on('error', reject);
      }
    ).on('error', reject);
  });
}

function downloadFile(url, destPath, onProgress) {
  return new Promise((resolve, reject) => {
    const u = new URL(url);
    https.get(
      { hostname: u.hostname, path: u.pathname + u.search,
        headers: { 'User-Agent': 'SecuriSite-Updater/1.0' } },
      (res) => {
        if (res.statusCode === 301 || res.statusCode === 302) {
          return downloadFile(res.headers.location, destPath, onProgress)
            .then(resolve).catch(reject);
        }
        const total = parseInt(res.headers['content-length'], 10);
        let downloaded = 0;
        const file = fs.createWriteStream(destPath);
        res.on('data', chunk => {
          downloaded += chunk.length;
          if (onProgress && total) onProgress(Math.floor((downloaded / total) * 100));
        });
        res.pipe(file);
        file.on('finish', () => file.close(resolve));
        file.on('error', (err) => { fs.unlink(destPath, () => {}); reject(err); });
      }
    ).on('error', reject);
  });
}

function createProgressWindow() {
  const win = new BrowserWindow({
    width: 380, height: 130,
    resizable: false, minimizable: false, maximizable: false,
    closable: false, alwaysOnTop: true, frame: false, skipTaskbar: true,
    webPreferences: { nodeIntegration: true, contextIsolation: false }
  });
  const html = '<html><head><meta charset="utf-8"></head><body style="margin:0;padding:20px;background:#1e2130;color:#e0e0e0;font-family:Segoe UI,sans-serif;user-select:none"><div id="msg" style="font-size:13px;margin-bottom:12px;color:#90caf9">Guncelleme indiriliyor, lutfen bekleyin...</div><div style="background:#2d3047;border-radius:6px;height:10px;overflow:hidden"><div id="bar" style="background:#42a5f5;height:10px;width:0%;transition:width 0.2s ease"></div></div><div id="pct" style="margin-top:8px;font-size:12px;color:#90a4ae;text-align:right">0%</div></body></html>';
  win.loadURL('data:text/html;charset=utf-8,' + encodeURIComponent(html));
  return win;
}

function extractZip(zipPath, destDir) {
  return new Promise((resolve, reject) => {
    const ps = require('child_process').spawn('powershell.exe', [
      '-NoProfile', '-NonInteractive', '-Command',
      `Expand-Archive -Path "${zipPath}" -DestinationPath "${destDir}" -Force`
    ], { stdio: 'pipe' });
    let stderr = '';
    ps.stderr.on('data', d => (stderr += d.toString()));
    ps.on('close', code => {
      if (code === 0) resolve();
      else reject(new Error('ZIP acma hatasi (kod ' + code + '): ' + stderr));
    });
  });
}

async function checkForUpdates(mainWindow) {
  try {
    console.log('[Updater] Guncelleme kontrol ediliyor...');
    const remote = await fetchJSON(VERSION_URL);
    const current = app.getVersion();
    if (!isNewer(remote.version, current)) {
      console.log('[Updater] Guncel: v' + current);
      return;
    }
    console.log('[Updater] Yeni surum: v' + remote.version);

    const { response } = await dialog.showMessageBox(mainWindow, {
      type: 'info',
      title: 'SecuriSite Guncelleme',
      message: 'Yeni surum mevcut: v' + remote.version,
      detail: 'Mevcut: v' + current + '\nYeni   : v' + remote.version +
              '\n\n' + (remote.notes || '') +
              '\n\nGuncelle butonuna tiklayin.\nProgram otomatik guncellenip yeniden baslayacak.',
      buttons: ['Simdi Guncelle', 'Sonra'],
      defaultId: 0,
      cancelId: 1
    });
    if (response === 1) return;

    const zipName    = 'SecuriSite-Update-' + remote.version + '.zip';
    const zipPath    = path.join(os.tmpdir(), zipName);
    const extractDir = path.join(os.tmpdir(), 'SecuriSite-Update-' + remote.version);

    if (fs.existsSync(zipPath)) fs.unlinkSync(zipPath);
    if (fs.existsSync(extractDir)) fs.rmSync(extractDir, { recursive: true, force: true });

    const progressWin = createProgressWindow();

    await downloadFile(remote.zip_url, zipPath, (pct) => {
      if (!progressWin.isDestroyed()) {
        progressWin.webContents.executeJavaScript(
          'document.getElementById("bar").style.width="' + pct + '%";' +
          'document.getElementById("pct").textContent="' + pct + '%";'
        ).catch(() => {});
      }
    });

    if (!progressWin.isDestroyed()) {
      progressWin.webContents.executeJavaScript(
        'document.getElementById("msg").textContent="ZIP aciliyor, lutfen bekleyin...";'
      ).catch(() => {});
    }

    await extractZip(zipPath, extractDir);
    if (!progressWin.isDestroyed()) progressWin.close();

    const appDir       = path.dirname(app.getAppPath());
    const extractedApp = path.join(extractDir, 'app');
    const exePath      = process.execPath;
    const batPath      = path.join(os.tmpdir(), 'securisite-apply-update.bat');

    const batLines = [
      '@echo off',
      'chcp 65001 > nul',
      'echo [SecuriSite Updater] Guncelleme uygulanıyor...',
      'timeout /t 3 /nobreak > nul',
      'robocopy "' + extractedApp + '" "' + appDir + '" /E /XD node_modules /IS /IT /IM > nul',
      'echo [SecuriSite Updater] Tamamlandi. Program baslatiliyor...',
      'start "" "' + exePath + '"',
      'del /f /q "' + zipPath + '" > nul 2>&1',
      'rmdir /s /q "' + extractDir + '" > nul 2>&1',
      'del /f /q "%~f0" > nul 2>&1',
      'exit'
    ];
    fs.writeFileSync(batPath, batLines.join('\r\n'), { encoding: 'utf8' });

    await dialog.showMessageBox(mainWindow, {
      type: 'info',
      title: 'Guncelleme Hazir',
      message: 'Indirme tamamlandi!',
      detail: 'Program simdi kapanacak ve otomatik guncellenip yeniden baslayacak.\nBir seyler yapmaniza gerek yok.',
      buttons: ['Tamam']
    });

    require('child_process').spawn('cmd.exe', ['/c', batPath], {
      detached: true,
      stdio: 'ignore',
      windowsHide: true
    }).unref();

    setTimeout(() => app.quit(), 1500);

  } catch (err) {
    console.error('[Updater] Hata:', err.message);
    try {
      await dialog.showMessageBox({
        type: 'error',
        title: 'Guncelleme Hatasi',
        message: 'Guncelleme sirasinda bir hata olustu.',
        detail: err.message,
        buttons: ['Tamam']
      });
    } catch (_) {}
  }
}

module.exports = { checkForUpdates };