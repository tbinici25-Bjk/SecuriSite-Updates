﻿import os
import shutil

APP_DIR = r"D:\SiteGuvenlik_Ana\resources\app"
MAIN_JS  = os.path.join(APP_DIR, "main.js")
UPDATER_JS = os.path.join(APP_DIR, "updater.js")
BACKUP   = os.path.join(APP_DIR, "main_updater_oncesi.js.bak")

shutil.copy2(MAIN_JS, BACKUP)
print(f"Yedek alindi: {BACKUP}")

UPDATER_CONTENT = r"""'use strict';

const { app, dialog, BrowserWindow } = require('electron');
const https = require('https');
const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');
const os = require('os');
const { URL } = require('url');

const VERSION_URL =
  'https://raw.githubusercontent.com/tbinici25-Bjk/SecuriSite-Updates/main/version.json';

function isNewer(remote, current) {
  const r = remote.split('.').map(Number);
  const c = current.split('.').map(Number);
  for (let i = 0; i < 3; i++) {
    if ((r[i] || 0) > (c[i] || 0)) return true;
    if ((r[i] || 0) < (c[i] || 0)) return false;
  }
  return false;
}

function fetchJSON(url) {
  return new Promise((resolve, reject) => {
    const u = new URL(url);
    https.get(
      { hostname: u.hostname, path: u.pathname + u.search,
        headers: { 'User-Agent': 'SecuriSite-Updater/1.0' } },
      (res) => {
        if (res.statusCode === 301 || res.statusCode === 302) {
          return fetchJSON(res.headers.location).then(resolve).catch(reject);
        }
        let data = '';
        res.on('data', chunk => (data += chunk));
        res.on('end', () => {
          try { resolve(JSON.parse(data)); }
          catch (e) { reject(new Error('JSON parse hatasi: ' + e.message)); }
        });
        res.on('error', reject);
      }
    ).on('error', reject);
  });
}

function downloadFile(url, destPath, onProgress) {
  return new Promise((resolve, reject) => {
    const u = new URL(url);
    https.get(
      { hostname: u.hostname, path: u.pathname + u.search,
        headers: { 'User-Agent': 'SecuriSite-Updater/1.0' } },
      (res) => {
        if (res.statusCode === 301 || res.statusCode === 302) {
          return downloadFile(res.headers.location, destPath, onProgress)
            .then(resolve).catch(reject);
        }
        const total = parseInt(res.headers['content-length'], 10);
        let downloaded = 0;
        const file = fs.createWriteStream(destPath);
        res.on('data', chunk => {
          downloaded += chunk.length;
          if (onProgress && total) onProgress(Math.floor((downloaded / total) * 100));
        });
        res.pipe(file);
        file.on('finish', () => file.close(resolve));
        file.on('error', (err) => { fs.unlink(destPath, () => {}); reject(err); });
      }
    ).on('error', reject);
  });
}

function createProgressWindow() {
  const win = new BrowserWindow({
    width: 380, height: 130,
    resizable: false, minimizable: false, maximizable: false,
    closable: false, alwaysOnTop: true, frame: false, skipTaskbar: true,
    webPreferences: { nodeIntegration: true, contextIsolation: false }
  });
  const html = '<html><head><meta charset="utf-8"></head><body style="margin:0;padding:20px;background:#1e2130;color:#e0e0e0;font-family:Segoe UI,sans-serif;user-select:none"><div style="font-size:13px;margin-bottom:12px;color:#90caf9">Guncelleme indiriliyor, lutfen bekleyin...</div><div style="background:#2d3047;border-radius:6px;height:10px;overflow:hidden"><div id="bar" style="background:#42a5f5;height:10px;width:0%;transition:width 0.2s ease"></div></div><div id="pct" style="margin-top:8px;font-size:12px;color:#90a4ae;text-align:right">0%</div></body></html>';
  win.loadURL('data:text/html;charset=utf-8,' + encodeURIComponent(html));
  return win;
}

async function checkForUpdates(mainWindow) {
  try {
    console.log('[Updater] Guncelleme kontrol ediliyor...');
    const remote = await fetchJSON(VERSION_URL);
    const current = app.getVersion();
    if (!isNewer(remote.version, current)) {
      console.log('[Updater] Guncel: v' + current);
      return;
    }
    console.log('[Updater] Yeni surum: v' + remote.version);
    const { response } = await dialog.showMessageBox(mainWindow, {
      type: 'info',
      title: 'SecuriSite Guncelleme',
      message: 'Yeni surum mevcut: v' + remote.version,
      detail: 'Mevcut: v' + current + '\nYeni   : v' + remote.version + '\n\n' + (remote.notes || '') + '\n\nGuncelle butonuna tiklayin.\nProgram otomatik guncellenip yeniden baslayacak.',
      buttons: ['Simdi Guncelle', 'Sonra'],
      defaultId: 0,
      cancelId: 1
    });
    if (response === 1) return;
    const installerName = 'SecuriSite-Setup-' + remote.version + '.exe';
    const installerPath = require('path').join(require('os').tmpdir(), installerName);
    if (require('fs').existsSync(installerPath)) require('fs').unlinkSync(installerPath);
    const progressWin = createProgressWindow();
    await downloadFile(remote.installer_url, installerPath, (pct) => {
      if (!progressWin.isDestroyed()) {
        progressWin.webContents.executeJavaScript(
          'document.getElementById("bar").style.width="' + pct + '%";document.getElementById("pct").textContent="' + pct + '%";'
        ).catch(() => {});
      }
    });
    if (!progressWin.isDestroyed()) progressWin.close();
    await dialog.showMessageBox(mainWindow, {
      type: 'info', title: 'Guncelleme Hazir',
      message: 'Indirme tamamlandi!',
      detail: 'Program simdi guncellenecek ve otomatik yeniden baslayacak.',
      buttons: ['Tamam']
    });
    require('child_process').spawn(installerPath, ['/S'], { detached: true, stdio: 'ignore' }).unref();
    setTimeout(() => app.quit(), 2000);
  } catch (err) {
    console.error('[Updater] Kontrol basarisiz (sessiz):', err.message);
  }
}

module.exports = { checkForUpdates };
"""

with open(UPDATER_JS, "w", encoding="utf-8") as f:
    f.write(UPDATER_CONTENT)
print(f"updater.js olusturuldu.")

with open(MAIN_JS, "r", encoding="utf-8") as f:
    content = f.read()

REQUIRE_OLD = "const fs = require('fs');"
REQUIRE_NEW = "const fs = require('fs');\nconst { checkForUpdates } = require('./updater');"

if "require('./updater')" in content:
    print("updater require zaten mevcut, atlandi.")
elif REQUIRE_OLD not in content:
    print("HATA: fs require satiri bulunamadi!")
    exit(1)
else:
    content = content.replace(REQUIRE_OLD, REQUIRE_NEW, 1)
    print("require('./updater') eklendi.")

INJECT_OLD = "mainWindow.once('ready-to-show', () => {\n        mainWindow.show();"
INJECT_NEW = "mainWindow.once('ready-to-show', () => {\n        mainWindow.show();\n        setTimeout(() => checkForUpdates(mainWindow), 5000);"

if "checkForUpdates(mainWindow)" in content:
    print("checkForUpdates zaten mevcut, atlandi.")
elif INJECT_OLD not in content:
    print("HATA: ready-to-show blogu bulunamadi!")
    exit(1)
else:
    content = content.replace(INJECT_OLD, INJECT_NEW, 1)
    print("checkForUpdates(mainWindow) eklendi.")

with open(MAIN_JS, "w", encoding="utf-8") as f:
    f.write(content)
print("main.js kaydedildi.")

with open(MAIN_JS, "r", encoding="utf-8") as f:
    lines = f.readlines()

found_require = any("require('./updater')" in l for l in lines)
found_call    = any("checkForUpdates(mainWindow)" in l for l in lines)

print("\n--- DOGRULAMA ---")
print(f"  require updater : {'OK' if found_require else 'HATA'}")
print(f"  checkForUpdates : {'OK' if found_call else 'HATA'}")
print(f"  updater.js      : {'OK' if os.path.exists(UPDATER_JS) else 'HATA'}")
print(f"  Yedek           : {'OK' if os.path.exists(BACKUP) else 'HATA'}")

if found_require and found_call and os.path.exists(UPDATER_JS):
    print("\nGuncelleme sistemi basariyla kuruldu!")
else:
    print("\nBir veya daha fazla adim basarisiz.")
